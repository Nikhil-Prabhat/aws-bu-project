package com.cognizant.exception;
@SuppressWarnings("serial")
public class TokenInvalidException extends Exception{
	public TokenInvalidException(String msg) {
		super(msg);
	}
}
