package com.cognizant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class IPTreatmentAuthApplicationTests {

	@Test
	void contextLoads() 
	{
		IPTreatmentAuthApplication.main(new String[] {});
	}

}
