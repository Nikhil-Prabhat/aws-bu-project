package com.cognizant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IpTreatmentServiceApplicationTests {

	@Test
	void contextLoads() {
		IpTreatmentServiceApplication.main(new String[] {});
	}

}
