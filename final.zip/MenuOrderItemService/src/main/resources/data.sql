
insert into orderitem (orderid,menuid,price,dateoforder,status) values (1,2,100.0,TO_DATE('19/10/2020', 'DD/MM/YYYY'),1);
insert into orderitem (orderid,menuid,price,dateoforder,status) values (2,3,200.0,TO_DATE('19/10/2020', 'DD/MM/YYYY'),1);
insert into orderitem (orderid,menuid,price,dateoforder,status) values (3,4,300.0,TO_DATE('19/10/2020', 'DD/MM/YYYY'),1);
insert into orderitem (orderid,menuid,price,dateoforder,status) values (4,2,250.0,TO_DATE('19/10/2020', 'DD/MM/YYYY'),1);
insert into orderitem (orderid,menuid,price,dateoforder,status) values (5,5,150.0,TO_DATE('19/10/2020', 'DD/MM/YYYY'),0);
