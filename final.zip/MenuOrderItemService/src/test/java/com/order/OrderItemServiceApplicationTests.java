package com.order;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class OrderItemServiceApplicationTests {

	@Test
	public void main() {
		OrderItemServiceApplication.main(new String[] {});
	}
}
