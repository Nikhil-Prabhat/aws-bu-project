package com.menuitem;


import org.junit.Test;

public class MenuItemServiceApplicationTests {

	@Test
    public void main() {
		MenuItemServiceApplication.main(new String[] {});
    }
	
	
}
