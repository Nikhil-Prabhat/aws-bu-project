
insert into menuitem (menuid,menuname,price,category,active) values (1,'A',100.0,'Aaa',1);
insert into menuitem (menuid,menuname,price,category,active) values (2,'B',200.0,'Baa',1);
insert into menuitem (menuid,menuname,price,category,active) values (3,'C',300.0,'Cdd',1);
insert into menuitem (menuid,menuname,price,category,active) values (4,'D',250.0,'Ddd',1);
insert into menuitem (menuid,menuname,price,category,active) values (5,'E',150.0,'Eee',0);
